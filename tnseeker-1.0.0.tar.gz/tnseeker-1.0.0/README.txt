on windows powersheel (on correct directory):
python setup.py sdist bdist_wheel

on anaconda/ubuntu:
pip install "/mnt/d/UNIL/Python_Programs/base_Essentials/dist/tnseeker-1.0.0.tar.gz"

to run module (any directory):
python -m EssentialFinder "/mnt/d/EMBL/Sam_Tnseq/NT12097/NT12097"

to run a script from the module:
python "D:\UNIL\Python\base_Essentials\EssentialFinder\Essential_Finder.py" "D:\EMBL\Sam_Tnseq\NT12004\Genbank" "BW25113" "gb" "D:\EMBL\Sequences\Tn5_strains"
python -m EssentialFinder -s BW25113 -sd "D:\EMBL\Sam_Tnseq\NT12004\Genbank" -ad "D:/EMBL/Sequences/Tn5_strains" -at gb -st SE --tn ACTTATCAGCCAACCTGT --e

python -m EssentialFinder -s BW25113 -sd "C:/Users/afons/Documents/Tn-Seq/Benchmark/BW25113 Goodall/BW25113" -ad "D:/EMBL/Sequences/Tn5_strains" -at gb -st SE --tn ACTTATCAGCCAACCTGT --e
python -m EssentialFinder -s Bacteroides_uniformis_ATCC_8492 -sd "C:/Users/afons/Documents/Tn-Seq/Carlos/liquid" -ad "D:/EMBL/Sequences/Tn5_strains" -at gff -st SE --tn ACTTATCAGCCAACCTGT --e

python -m EssentialFinder -s UTI89 -sd "/mnt/d/EMBL/Sudoku/Sudoku_fastq_june_2021/pool_data_sudoko" -ad "/mnt/d/EMBL/Sequences/Tn5_strains" -at gb -st SE --tn AGATGTGTATAAGAGACAG --k --b --rt 5

python -m EssentialFinder -s NT12004 -sd "/mnt/d/EMBL/Sam_Tnseq/NT12004/NT12004" -ad "/mnt/d/EMBL/Sequences/Tn5_strains" -at gff -st PE --tn AGATGTGTATAAGAGACAG --k --b --rt 5
