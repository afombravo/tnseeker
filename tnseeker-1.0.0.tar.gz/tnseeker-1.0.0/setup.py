from setuptools import setup, find_packages

VERSION = '1.0.0' 
DESCRIPTION = 'TnSeeker'
LONG_DESCRIPTION = 'Python3 Module to infer gene essentiality for any given species by Tn-Seq. Required illumina sequencing, and gff/genbank annotation files'

# Setting up
setup(
       # the name must match the folder name 'verysimplemodule'
        name="tnseeker", 
        version=VERSION,
        author="Afonso M Bravo",
        author_email="<afonsombravo@hotmail.com>",
        url='None',
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        packages=find_packages(),
        install_requires=["numpy >= 1.19.2",
                           "matplotlib >= 3.3.4",
                           "numba >= 0.53.1",
                           "biopython >= 1.81",
                           "datetime",
                           "argparse",
                           "regex",
                           "multiprocess",
                           "pathlib",
                           "scipy >= 1.6.2",
                           "seaborn >= 0.12.1",
                           "statsmodels >= 0.12.2"],
        
        keywords=['tnseq', 'essentiality'],
        classifiers= [
            "Development Status :: 3 - Alpha",
            "Intended Audience :: Education",
            "Programming Language :: Python :: 3",
            "Operating System :: OS Independent",
        ]
)