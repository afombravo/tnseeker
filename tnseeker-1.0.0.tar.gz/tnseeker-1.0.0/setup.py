from setuptools import setup, find_packages

VERSION = '1.0.0' 
DESCRIPTION = 'Tn Seeker'
LONG_DESCRIPTION = 'Python3 Module to infer gene essentiality for any given species by Tn-Seq. Required illumina sequencing, and gff/genbank annotation files'

# Setting up
setup(
       # the name must match the folder name 'verysimplemodule'
        name="tnseeker", 
        version=VERSION,
        author="Afonso M Bravo",
        author_email="<afonsombravo@hotmail.com>",
        url='None',
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        packages=find_packages(),
        install_requires=[],
        
        keywords=['tnseq', 'essentiality'],
        classifiers= [
            "Development Status :: 3 - Alpha",
            "Intended Audience :: Education",
            "Programming Language :: Python :: 3",
            "Operating System :: OS Independent",
        ]
)